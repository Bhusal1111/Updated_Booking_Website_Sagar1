# Open_Gift_Box
Project I did to open gift boxes using JavaScript.
<img width="599" alt="ss3" src="https://github.com/user-attachments/assets/d0ed940d-2590-4391-aa1a-e4e1bfabdbe9" />
