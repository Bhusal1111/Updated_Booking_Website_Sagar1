﻿# Updated_Booking_Website
 A Website which allows tourist to go thorugh the popular attractions of the popular cities in nepal while also being able to book for the hotels.
![Screenshot 2025-02-25 142835](https://github.com/user-attachments/assets/4044d8cd-efc5-4442-8360-178014a9bb8e)
![Screenshot 2025-02-25 142801](https://github.com/user-attachments/assets/f6d93a5a-8920-46bd-b529-036b72ea49b7)
![Screenshot 2025-02-25 142721](https://github.com/user-attachments/assets/e8ae06e5-6c83-4b28-9b78-bc0c3235748f)
